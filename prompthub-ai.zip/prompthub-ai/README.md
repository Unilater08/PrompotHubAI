# PromptHub AI

Biblioteca de prompts prontos para IA. Pesquise, visualize e copie prompts para ChatGPT, Claude, Gemini, Midjourney e outras IAs em segundos.

MVP construído com foco em **velocidade**, **simplicidade** e **escalabilidade**.

---

## ✨ Stack

| Camada         | Tecnologia                          |
| -------------- | ------------------------------------ |
| Frontend       | React + Next.js 14 (App Router) + TypeScript |
| Estilo         | TailwindCSS + shadcn/ui              |
| Backend/Banco  | Supabase (PostgreSQL)                |
| Autenticação   | Supabase Auth (Email/Senha + Google) |
| Hospedagem     | Vercel                               |

---

## 📁 Estrutura de pastas

```
src/
  app/                 # Rotas (App Router)
    page.tsx           # Tela inicial
    login/             # Login / cadastro / recuperação de senha
    dashboard/         # Listagem e busca de prompts
    categorias/        # Lista de categorias + página por categoria
    prompt/[id]/       # Página de detalhe do prompt
    perfil/            # Perfil do usuário
    auth/callback/     # Callback do OAuth (Google)
  components/
    ui/                # Componentes shadcn/ui (button, card, input...)
    layout/            # Navbar, Footer
    prompts/           # PromptCard, SearchBar, Filtros, Grid
    categories/        # CategoryCard
    providers/         # ThemeProvider, ThemeToggle
  hooks/               # useAuth, usePrompts, useCategories, useDebounce...
  services/            # Camada de acesso a dados (Supabase) + auth
  types/               # Tipos TypeScript compartilhados
  utils/               # Formatação, ícones, helpers
  lib/                 # utilitário cn() (shadcn)
supabase/
  schema.sql           # Schema do banco + RLS + RPC
  seed.ts              # Script de seed com categorias e ~50 prompts
```

---

## 🚀 Como rodar localmente

### 1. Pré-requisitos
- Node.js 18+
- Uma conta gratuita em [supabase.com](https://supabase.com)

### 2. Clonar e instalar dependências
```bash
npm install
```

### 3. Criar o projeto no Supabase
1. Crie um novo projeto em [supabase.com](https://supabase.com).
2. Em **SQL Editor**, cole e execute o conteúdo de `supabase/schema.sql`.
3. Em **Authentication → Providers**, habilite **Email** e, se desejar, **Google** (configure o Client ID/Secret do Google Cloud Console).
4. Em **Authentication → URL Configuration**, adicione `http://localhost:3000/auth/callback` (e a URL de produção depois) como Redirect URL.

### 4. Configurar variáveis de ambiente
Copie o arquivo de exemplo:
```bash
cp .env.example .env
```
Preencha com os dados do seu projeto Supabase (em **Project Settings → API**):
```
NEXT_PUBLIC_SUPABASE_URL=https://seu-projeto.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sua-anon-key
SUPABASE_SERVICE_ROLE_KEY=sua-service-role-key   # usada apenas pelo script de seed
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```
⚠️ A `SUPABASE_SERVICE_ROLE_KEY` nunca deve ser exposta no frontend — ela é usada apenas localmente pelo script `npm run seed`.

### 5. Popular o banco com dados de exemplo
```bash
npm run seed
```
Isso cria as 10 categorias e aproximadamente 50 prompts de exemplo.

### 6. Rodar o projeto
```bash
npm run dev
```
Acesse [http://localhost:3000](http://localhost:3000).

---

## ☁️ Deploy na Vercel

1. Suba o projeto para um repositório no GitHub/GitLab.
2. Importe o repositório em [vercel.com/new](https://vercel.com/new).
3. Configure as variáveis de ambiente do projeto (as mesmas do `.env`, exceto a `SUPABASE_SERVICE_ROLE_KEY`, que **não deve** ir para a Vercel — o seed é executado apenas localmente ou em um ambiente seguro).
4. Adicione a URL de produção (`https://seu-dominio.vercel.app/auth/callback`) nas **Redirect URLs** do Supabase.
5. Deploy 🚀

---

## 🗃️ Modelo de dados

- **users** — perfil público do usuário (sincronizado automaticamente com `auth.users` via trigger).
- **categories** — categorias de prompts (Marketing, Instagram, WhatsApp, etc).
- **prompts** — conteúdo dos prompts, com categoria, nível, tipo de IA, tags e contador de cópias.
- **history** — histórico de prompts copiados por cada usuário autenticado.

Todas as tabelas possuem **Row Level Security (RLS)** habilitada: prompts e categorias são públicos para leitura; o histórico e o perfil só podem ser acessados pelo próprio usuário.

---

## ✅ Funcionalidades da V1

- Pesquisa em tempo real (com debounce) por título, descrição e tags
- Filtros por categoria, nível de dificuldade e tipo de IA
- Cópia de prompt com um clique (com contagem de cópias)
- Histórico de prompts copiados por usuário autenticado
- Login com e-mail/senha, Google OAuth e recuperação de senha
- Tema claro/escuro com persistência
- Totalmente responsivo (mobile, tablet, desktop)
- Renderização no servidor (SSR/ISR) nas páginas de listagem para carregamento rápido e SEO

## 🚫 Fora do escopo da V1 (intencionalmente)
Pagamentos, favoritos, comentários, geração de prompts por IA e painel administrativo — para manter o lançamento rápido e o MVP enxuto. A arquitetura (services/hooks/types separados) foi pensada para que essas features sejam adicionadas depois sem retrabalho.

---

## 🧩 Próximos passos sugeridos
- Favoritar prompts
- Geração de prompts personalizados com IA
- Planos pagos (Stripe)
- Painel administrativo para CRUD de prompts
- Comentários e avaliações por prompt

---

## 🛡️ Correções da auditoria técnica (06/2026)

Após uma auditoria técnica completa, as seguintes correções **críticas e importantes** foram aplicadas ao código. Itens não listados aqui (ex: particionamento de `history`, cache de borda, geração automática de tipos do Supabase) seguem como melhorias futuras documentadas no relatório de auditoria.

### Segurança
- A RPC `increment_copy_count` agora **exige autenticação** (`auth.uid()`) e ignora chamadas repetidas do mesmo usuário/prompt em uma janela de 10 segundos, impedindo que visitantes anônimos inflassem a métrica de "prompts populares" (`supabase/schema.sql`).
- O termo de busca agora é **escapado** antes de ser interpolado no filtro `.or()` do PostgREST, eliminando o risco de um usuário manipular a lógica do filtro com vírgulas/parênteses/aspas (`src/services/prompts.service.ts`).
- `/perfil` (e demais rotas protegidas) agora é bloqueado **no middleware**, antes de qualquer HTML ser enviado — não depende mais só de um `useEffect` no client (`src/services/supabase/middleware.ts`, `src/middleware.ts`).
- Adicionados security headers (`CSP`, `X-Frame-Options`, `Referrer-Policy`, `Strict-Transport-Security`, `Permissions-Policy`) em `next.config.js`.

### Performance e escalabilidade
- `getPrompts()` agora pagina de verdade via `.range()` + `count: "exact"`, em vez de buscar todos os registros de uma vez (`src/services/prompts.service.ts`, `src/hooks/use-prompts.ts`, com botão "Carregar mais" no Dashboard).
- A página de categoria (`/categorias/[slug]`) também é paginada no servidor (`?page=`), em vez de carregar todos os prompts da categoria de uma só vez.
- A contagem de prompts por categoria em `/categorias` agora usa `count: "exact", head: true` por categoria, em vez de baixar a tabela inteira de prompts para contar em JavaScript.
- Trocado o índice de busca textual não utilizado por índices **trigram (`pg_trgm`)**, que realmente aceleram o `ilike '%termo%'` usado pela aplicação; adicionado índice GIN em `tags` (`supabase/schema.sql`).

### Qualidade e confiabilidade
- Adicionada configuração de **ESLint** (`.eslintrc.json`) e **Prettier** (`.prettierrc.json`), antes ausentes.
- Adicionados **testes unitários** (Vitest) cobrindo a correção de injeção de filtro e os utilitários de formatação (`src/**/*.test.ts`). Rode com `npm run test`.
- Adicionado pipeline de **CI** no GitHub Actions (`.github/workflows/ci.yml`): typecheck, lint, testes e build a cada PR.
- A lógica de "copiar prompt" (duplicada antes em dois componentes) foi unificada no hook `useCopyPrompt` (`src/hooks/use-copy-prompt.ts`).
- Erros de rede deixaram de ser descartados silenciosamente: `usePrompts` expõe `error` e o Dashboard agora exibe um alerta visual em vez de confundir falha de rede com "nenhum resultado encontrado".
- Adicionados `loading.tsx` em todas as rotas e `error.tsx`/`global-error.tsx` com a identidade visual do produto, em vez da tela de erro genérica do Next.js.

### SEO
- Adicionados `sitemap.ts` (dinâmico, incluindo categorias e prompts) e `robots.ts`, antes inexistentes.
- Adicionado `twitter` card no metadata raiz (`src/app/layout.tsx`).

### Como rodar os testes
```bash
npm run test        # roda todos os testes uma vez
npm run test:watch  # modo watch durante o desenvolvimento
```

### Variáveis de ambiente no CI
Se for usar o workflow `.github/workflows/ci.yml` tal como está, configure os secrets `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` e `NEXT_PUBLIC_SITE_URL` no GitHub (Settings → Secrets and variables → Actions), já que o `next build` precisa dessas variáveis para gerar o `sitemap.ts`/páginas estáticas corretamente.
