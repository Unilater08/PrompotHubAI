import { describe, expect, it } from "vitest";
import { buildSearchFilter, escapePostgrestFilterValue } from "@/services/prompts.service";

describe("escapePostgrestFilterValue", () => {
  it("wraps the value in double quotes", () => {
    expect(escapePostgrestFilterValue("ola")).toBe('"ola"');
  });

  it("escapes internal double quotes", () => {
    expect(escapePostgrestFilterValue('a"b')).toBe('"a\\"b"');
  });

  it("escapes backslashes", () => {
    expect(escapePostgrestFilterValue("a\\b")).toBe('"a\\\\b"');
  });
});

describe("buildSearchFilter (regressão da vulnerabilidade de injeção de filtro)", () => {
  it("mantém uma busca normal funcionando", () => {
    const filter = buildSearchFilter("marketing");
    expect(filter).toBe('titulo.ilike."%marketing%",descricao.ilike."%marketing%"');
  });

  it("neutraliza uma tentativa de injetar uma condição extra via vírgula", () => {
    // Antes da correção, um termo como este poderia injetar uma condição
    // adicional na query (`categoria_id.eq.<uuid>`), pois a string era
    // interpolada sem escape na sintaxe de filtros do PostgREST.
    const malicious = 'a",categoria_id.eq.algum-id-arbitrario,titulo.ilike."%';
    const filter = buildSearchFilter(malicious);

    // O valor malicioso inteiro deve permanecer dentro de um único literal
    // entre aspas, e não se transformar em uma terceira condição de filtro.
    expect(filter.startsWith('titulo.ilike."%')).toBe(true);
    expect(filter).not.toContain('categoria_id.eq.algum-id-arbitrario"');
  });

  it("escapa aspas duplas dentro do termo de busca", () => {
    const filter = buildSearchFilter('teste"injetado');
    expect(filter).toContain('teste\\"injetado');
  });
});
