import { createClient } from "@/services/supabase/client";
import type { HistoryItem } from "@/types";

export async function registerCopy(promptId: string, userId: string | null): Promise<void> {
  if (!userId) return;
  const supabase = createClient();
  const { error } = await supabase.from("history").insert({ prompt_id: promptId, user_id: userId });
  if (error) throw error;
}

export async function getUserHistory(userId: string): Promise<HistoryItem[]> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from("history")
    .select("*, prompt:prompts(*, category:categories(*))")
    .eq("user_id", userId)
    .order("created_at", { ascending: false });

  if (error) throw error;
  return (data ?? []) as unknown as HistoryItem[];
}

export async function getUserCopyCount(userId: string): Promise<number> {
  const supabase = createClient();
  const { count, error } = await supabase
    .from("history")
    .select("*", { count: "exact", head: true })
    .eq("user_id", userId);

  if (error) return 0;
  return count ?? 0;
}
