import { createClient } from "@/services/supabase/client";
import type { Prompt, PromptFilters } from "@/types";

const SELECT_PROMPT = "*, category:categories(*)";
export const DEFAULT_PAGE_SIZE = 24;

export interface PaginatedResult<T> {
  items: T[];
  count: number;
  page: number;
  pageSize: number;
  hasMore: boolean;
}

export interface Pagination {
  page?: number;
  pageSize?: number;
}

/**
 * Escapa um valor antes de usá-lo dentro da sintaxe de filtros do PostgREST
 * (usada por `.or()`). Sem isso, caracteres como `,`, `(` e `)` digitados
 * pelo usuário poderiam alterar a estrutura lógica do filtro (ex: injetar
 * uma condição extra). O PostgREST aceita valores com caracteres especiais
 * desde que estejam entre aspas duplas, com aspas internas escapadas.
 * Ver: https://postgrest.org/en/stable/references/api/tables_views.html#operators
 */
export function escapePostgrestFilterValue(value: string): string {
  return `"${value.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
}

export function buildSearchFilter(term: string): string {
  const safePattern = escapePostgrestFilterValue(`%${term}%`);
  return `titulo.ilike.${safePattern},descricao.ilike.${safePattern}`;
}

/**
 * Lista prompts com filtros e paginação real via `.range()`.
 * Antes desta correção, a função buscava TODOS os prompts que passassem o
 * filtro de uma só vez — inviável a partir de algumas centenas de milhares
 * de registros (e silenciosamente truncado pelo limite padrão do PostgREST).
 */
export async function getPrompts(
  filters: PromptFilters = {},
  pagination: Pagination = {}
): Promise<PaginatedResult<Prompt>> {
  const supabase = createClient();
  const page = Math.max(1, pagination.page ?? 1);
  const pageSize = pagination.pageSize ?? DEFAULT_PAGE_SIZE;
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  let query = supabase
    .from("prompts")
    .select(SELECT_PROMPT, { count: "exact" })
    .order("created_at", { ascending: false })
    .range(from, to);

  if (filters.search && filters.search.trim().length > 0) {
    query = query.or(buildSearchFilter(filters.search.trim()));
  }

  if (filters.categoria && filters.categoria !== "todos") {
    query = query.eq("categoria_id", filters.categoria);
  }

  if (filters.nivel && filters.nivel !== "todos") {
    query = query.eq("nivel", filters.nivel);
  }

  if (filters.tipo_ia && filters.tipo_ia !== "todos") {
    query = query.eq("tipo_ia", filters.tipo_ia);
  }

  const { data, error, count } = await query;

  if (error) throw error;

  const total = count ?? 0;
  return {
    items: (data ?? []) as unknown as Prompt[],
    count: total,
    page,
    pageSize,
    hasMore: from + (data?.length ?? 0) < total,
  };
}

export async function getPromptById(id: string): Promise<Prompt | null> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from("prompts")
    .select(SELECT_PROMPT)
    .eq("id", id)
    .single();

  if (error) return null;
  return data as unknown as Prompt;
}

export async function getPopularPrompts(limit = 6): Promise<Prompt[]> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from("prompts")
    .select(SELECT_PROMPT)
    .order("copy_count", { ascending: false })
    .limit(limit);

  if (error) throw error;
  return (data ?? []) as unknown as Prompt[];
}

export async function getRecentPrompts(limit = 6): Promise<Prompt[]> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from("prompts")
    .select(SELECT_PROMPT)
    .order("created_at", { ascending: false })
    .limit(limit);

  if (error) throw error;
  return (data ?? []) as unknown as Prompt[];
}

/**
 * Incrementa o contador de cópias de um prompt.
 * A RPC agora exige autenticação (ver supabase/schema.sql) — chamadas de
 * usuários anônimos vão falhar de propósito, então só deve ser chamada
 * quando houver um usuário logado. O erro é propagado (não engolido) para
 * que quem chamar decida como tratar/logar.
 */
export async function incrementCopyCount(promptId: string): Promise<void> {
  const supabase = createClient();
  const { error } = await supabase.rpc("increment_copy_count", { prompt_id: promptId });
  if (error) throw error;
}
