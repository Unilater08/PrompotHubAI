import { createClient } from "@/services/supabase/client";

export async function signInWithEmail(email: string, password: string) {
  const supabase = createClient();
  return supabase.auth.signInWithPassword({ email, password });
}

export async function signUpWithEmail(email: string, password: string, nome: string) {
  const supabase = createClient();
  return supabase.auth.signUp({
    email,
    password,
    options: { data: { nome } },
  });
}

export async function signInWithGoogle() {
  const supabase = createClient();
  const redirectTo = `${process.env.NEXT_PUBLIC_SITE_URL ?? window.location.origin}/auth/callback`;
  return supabase.auth.signInWithOAuth({
    provider: "google",
    options: { redirectTo },
  });
}

export async function sendPasswordReset(email: string) {
  const supabase = createClient();
  const redirectTo = `${process.env.NEXT_PUBLIC_SITE_URL ?? window.location.origin}/login?reset=true`;
  return supabase.auth.resetPasswordForEmail(email, { redirectTo });
}

export async function signOut() {
  const supabase = createClient();
  return supabase.auth.signOut();
}
