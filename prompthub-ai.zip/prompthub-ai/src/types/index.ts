export type Nivel = "iniciante" | "intermediario" | "avancado";

export type TipoIA =
  | "ChatGPT"
  | "Claude"
  | "Gemini"
  | "Midjourney"
  | "DALL-E"
  | "Copilot"
  | "Outra";

export interface Category {
  id: string;
  nome: string;
  slug: string;
  icone: string;
  descricao: string | null;
  created_at: string;
}

export interface Prompt {
  id: string;
  titulo: string;
  descricao: string;
  conteudo: string;
  categoria_id: string;
  nivel: Nivel;
  tipo_ia: TipoIA;
  tags: string[];
  tempo_leitura: number;
  exemplo_resultado: string | null;
  copy_count: number;
  created_at: string;
  category?: Category;
}

export interface HistoryItem {
  id: string;
  user_id: string;
  prompt_id: string;
  created_at: string;
  prompt?: Prompt;
}

export interface Profile {
  id: string;
  nome: string;
  email: string;
  foto: string | null;
  plano: "gratuito" | "pro";
  created_at: string;
}

export interface PromptFilters {
  search?: string;
  categoria?: string;
  nivel?: Nivel | "todos";
  tipo_ia?: TipoIA | "todos";
}
