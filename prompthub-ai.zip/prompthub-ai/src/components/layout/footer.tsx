import Link from "next/link";
import { Sparkles } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-border/60">
      <div className="container flex flex-col items-center justify-between gap-4 py-8 sm:flex-row">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Sparkles className="h-4 w-4" />
          <span>PromptHub AI © {new Date().getFullYear()}</span>
        </div>
        <nav className="flex items-center gap-6 text-sm text-muted-foreground">
          <Link href="/dashboard" className="hover:text-foreground">Prompts</Link>
          <Link href="/categorias" className="hover:text-foreground">Categorias</Link>
          <Link href="/login" className="hover:text-foreground">Entrar</Link>
        </nav>
      </div>
    </footer>
  );
}
