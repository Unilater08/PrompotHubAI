"use client";

import type { MouseEvent } from "react";
import Link from "next/link";
import { Check, Copy, ArrowUpRight } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useCopyPrompt } from "@/hooks/use-copy-prompt";
import { getCategoryIcon } from "@/utils/icons";
import { formatNivel, nivelColor, truncate } from "@/utils/format";
import type { Prompt } from "@/types";

interface PromptCardProps {
  prompt: Prompt;
}

export function PromptCard({ prompt }: PromptCardProps) {
  const { copied, copyPrompt } = useCopyPrompt(prompt.id, prompt.conteudo);
  const Icon = getCategoryIcon(prompt.category?.icone ?? "zap");

  async function handleCopy(e: MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    await copyPrompt();
  }

  return (
    <Card className="group flex h-full flex-col justify-between transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <Icon className="h-4 w-4" />
          </span>
          <Badge variant="muted" className={nivelColor(prompt.nivel)}>
            {formatNivel(prompt.nivel)}
          </Badge>
        </div>
        <h3 className="mt-2 font-display text-base font-semibold leading-snug tracking-tight">
          {prompt.titulo}
        </h3>
        <p className="text-xs font-medium text-muted-foreground">
          {prompt.category?.nome} · {prompt.tipo_ia}
        </p>
      </CardHeader>
      <CardContent className="flex flex-1 flex-col justify-between gap-4 pt-0">
        <p className="text-sm text-muted-foreground">{truncate(prompt.descricao, 100)}</p>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="secondary" className="flex-1" onClick={handleCopy}>
            {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
            {copied ? "Copiado!" : "Copiar"}
          </Button>
          <Button size="sm" variant="outline" asChild className="flex-1">
            <Link href={`/prompt/${prompt.id}`}>
              Abrir <ArrowUpRight className="h-3.5 w-3.5" />
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
