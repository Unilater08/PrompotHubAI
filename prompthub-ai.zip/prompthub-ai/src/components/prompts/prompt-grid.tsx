import { Search } from "lucide-react";
import { PromptCard } from "@/components/prompts/prompt-card";
import { Skeleton } from "@/components/ui/skeleton";
import type { Prompt } from "@/types";

interface PromptGridProps {
  prompts: Prompt[];
  loading?: boolean;
}

export function PromptGrid({ prompts, loading }: PromptGridProps) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-56 w-full rounded-xl" />
        ))}
      </div>
    );
  }

  if (prompts.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-border py-20 text-center">
        <span className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
          <Search className="h-5 w-5 text-muted-foreground" />
        </span>
        <p className="font-medium">Nenhum prompt encontrado</p>
        <p className="max-w-xs text-sm text-muted-foreground">
          Tente outro termo de pesquisa ou ajuste os filtros para encontrar o que precisa.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 animate-fade-in">
      {prompts.map((prompt) => (
        <PromptCard key={prompt.id} prompt={prompt} />
      ))}
    </div>
  );
}
