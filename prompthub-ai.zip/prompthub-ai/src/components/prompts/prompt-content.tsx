"use client";

import { Check, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCopyPrompt } from "@/hooks/use-copy-prompt";

interface PromptContentProps {
  promptId: string;
  conteudo: string;
}

export function PromptContent({ promptId, conteudo }: PromptContentProps) {
  const { copied, copyPrompt } = useCopyPrompt(promptId, conteudo);

  return (
    <div className="rounded-xl border border-border bg-muted/40">
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <span className="text-xs font-medium text-muted-foreground">Prompt completo</span>
        <Button size="sm" onClick={copyPrompt}>
          {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
          {copied ? "Copiado!" : "Copiar prompt"}
        </Button>
      </div>
      <pre className="max-h-[480px] overflow-auto whitespace-pre-wrap p-4 font-mono text-sm leading-relaxed">
        {conteudo}
      </pre>
    </div>
  );
}
