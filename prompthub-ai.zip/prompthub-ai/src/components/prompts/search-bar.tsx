"use client";

import { Search, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  size?: "default" | "lg";
  className?: string;
}

export function SearchBar({ value, onChange, placeholder, size = "default", className }: SearchBarProps) {
  return (
    <div className={cn("relative w-full", className)}>
      <Search
        className={cn(
          "pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground",
          size === "lg" ? "h-5 w-5" : "h-4 w-4"
        )}
      />
      <Input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder ?? "Pesquisar prompts…"}
        className={cn(
          "shadow-sm",
          size === "lg" ? "h-14 rounded-2xl pl-12 pr-12 text-base" : "h-10 rounded-lg pl-10 pr-9 text-sm"
        )}
      />
      {value.length > 0 && (
        <button
          type="button"
          onClick={() => onChange("")}
          aria-label="Limpar pesquisa"
          className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground transition-colors hover:text-foreground"
        >
          <X className={size === "lg" ? "h-5 w-5" : "h-4 w-4"} />
        </button>
      )}
    </div>
  );
}
