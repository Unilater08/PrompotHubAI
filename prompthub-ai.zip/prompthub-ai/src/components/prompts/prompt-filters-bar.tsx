"use client";

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { Category, Nivel, PromptFilters, TipoIA } from "@/types";

interface PromptFiltersBarProps {
  categories: Category[];
  filters: PromptFilters;
  onChange: (filters: PromptFilters) => void;
}

const NIVEIS: { value: Nivel | "todos"; label: string }[] = [
  { value: "todos", label: "Todos os níveis" },
  { value: "iniciante", label: "Iniciante" },
  { value: "intermediario", label: "Intermediário" },
  { value: "avancado", label: "Avançado" },
];

const TIPOS_IA: { value: TipoIA | "todos"; label: string }[] = [
  { value: "todos", label: "Todas as IAs" },
  { value: "ChatGPT", label: "ChatGPT" },
  { value: "Claude", label: "Claude" },
  { value: "Gemini", label: "Gemini" },
  { value: "Midjourney", label: "Midjourney" },
  { value: "DALL-E", label: "DALL-E" },
  { value: "Copilot", label: "Copilot" },
  { value: "Outra", label: "Outra" },
];

export function PromptFiltersBar({ categories, filters, onChange }: PromptFiltersBarProps) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row">
      <Select
        value={filters.categoria ?? "todos"}
        onValueChange={(value) => onChange({ ...filters, categoria: value })}
      >
        <SelectTrigger className="sm:w-48">
          <SelectValue placeholder="Categoria" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="todos">Todas as categorias</SelectItem>
          {categories.map((cat) => (
            <SelectItem key={cat.id} value={cat.id}>
              {cat.nome}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select
        value={filters.nivel ?? "todos"}
        onValueChange={(value) => onChange({ ...filters, nivel: value as Nivel | "todos" })}
      >
        <SelectTrigger className="sm:w-48">
          <SelectValue placeholder="Nível" />
        </SelectTrigger>
        <SelectContent>
          {NIVEIS.map((n) => (
            <SelectItem key={n.value} value={n.value}>
              {n.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select
        value={filters.tipo_ia ?? "todos"}
        onValueChange={(value) => onChange({ ...filters, tipo_ia: value as TipoIA | "todos" })}
      >
        <SelectTrigger className="sm:w-48">
          <SelectValue placeholder="IA" />
        </SelectTrigger>
        <SelectContent>
          {TIPOS_IA.map((t) => (
            <SelectItem key={t.value} value={t.value}>
              {t.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
