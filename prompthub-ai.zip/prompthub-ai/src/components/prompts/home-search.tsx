"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { KeyboardEvent } from "react";
import { SearchBar } from "@/components/prompts/search-bar";

export function HomeSearch() {
  const [value, setValue] = useState("");
  const router = useRouter();

  function handleChange(next: string) {
    setValue(next);
  }

  function goToDashboard(e: KeyboardEvent<HTMLDivElement>) {
    if (e.key === "Enter") {
      router.push(`/dashboard?q=${encodeURIComponent(value)}`);
    }
  }

  return (
    <div className="w-full max-w-xl" onKeyDown={goToDashboard}>
      <SearchBar
        value={value}
        onChange={handleChange}
        size="lg"
        placeholder="Ex: prompt para legenda de Instagram…"
      />
    </div>
  );
}
