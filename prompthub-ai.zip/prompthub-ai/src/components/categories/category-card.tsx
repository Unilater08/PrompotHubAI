import Link from "next/link";
import { Card } from "@/components/ui/card";
import { getCategoryIcon } from "@/utils/icons";
import type { Category } from "@/types";

interface CategoryCardProps {
  category: Category;
  count?: number;
}

export function CategoryCard({ category, count }: CategoryCardProps) {
  const Icon = getCategoryIcon(category.icone);

  return (
    <Link href={`/categorias/${category.slug}`}>
      <Card className="group flex flex-col gap-3 p-5 transition-all duration-200 hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md">
        <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
          <Icon className="h-5 w-5" />
        </span>
        <div>
          <p className="font-display font-semibold tracking-tight">{category.nome}</p>
          {typeof count === "number" && (
            <p className="text-xs text-muted-foreground">{count} prompts</p>
          )}
        </div>
      </Card>
    </Link>
  );
}
