"use client";

import { useCallback } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useCopyToClipboard } from "@/hooks/use-copy-to-clipboard";
import { incrementCopyCount } from "@/services/prompts.service";
import { registerCopy } from "@/services/history.service";

/**
 * Centraliza a ação de "copiar prompt": copia para a área de transferência e,
 * se houver um usuário autenticado, registra a cópia (RPC + histórico).
 *
 * Antes esta lógica estava duplicada em PromptCard e PromptContent, e os
 * erros das chamadas de rede eram descartados silenciosamente
 * (`.catch(() => {})`), o que escondia falhas em produção. Agora:
 * - a lógica vive em um único lugar;
 * - usuários anônimos não tentam mais chamar a RPC (que agora exige login —
 *   ver supabase/schema.sql), evitando uma chamada que sempre falharia;
 * - erros são logados no console (e podem futuramente ser enviados a uma
 *   ferramenta de observabilidade, ex: Sentry) em vez de desaparecer.
 */
export function useCopyPrompt(promptId: string, conteudo: string) {
  const { copied, copy } = useCopyToClipboard();
  const { user } = useAuth();

  const copyPrompt = useCallback(async () => {
    const ok = await copy(conteudo);
    if (!ok) return false;

    if (user) {
      try {
        await incrementCopyCount(promptId);
        await registerCopy(promptId, user.id);
      } catch (err) {
        // eslint-disable-next-line no-console
        console.error("Falha ao registrar a cópia do prompt:", err);
      }
    }

    return true;
  }, [copy, conteudo, promptId, user]);

  return { copied, copyPrompt };
}
