"use client";

import { useCallback, useEffect, useState } from "react";
import { DEFAULT_PAGE_SIZE, getPrompts } from "@/services/prompts.service";
import type { Prompt, PromptFilters } from "@/types";

export function usePrompts(filters: PromptFilters, pageSize = DEFAULT_PAGE_SIZE) {
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [page, setPage] = useState(1);
  const [count, setCount] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Refaz a busca do início sempre que os filtros mudam
  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);

    getPrompts(filters, { page: 1, pageSize })
      .then((result) => {
        if (!active) return;
        setPrompts(result.items);
        setCount(result.count);
        setHasMore(result.hasMore);
        setPage(1);
      })
      .catch((err) => {
        if (active) setError(err?.message ?? "Erro ao carregar prompts. Tente novamente.");
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters.search, filters.categoria, filters.nivel, filters.tipo_ia, pageSize]);

  const loadMore = useCallback(async () => {
    if (loadingMore || !hasMore) return;
    setLoadingMore(true);
    setError(null);
    try {
      const nextPage = page + 1;
      const result = await getPrompts(filters, { page: nextPage, pageSize });
      setPrompts((prev) => [...prev, ...result.items]);
      setHasMore(result.hasMore);
      setPage(nextPage);
    } catch (err: any) {
      setError(err?.message ?? "Erro ao carregar mais prompts. Tente novamente.");
    } finally {
      setLoadingMore(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters.search, filters.categoria, filters.nivel, filters.tipo_ia, page, hasMore, loadingMore, pageSize]);

  return { prompts, count, loading, loadingMore, hasMore, error, loadMore };
}
