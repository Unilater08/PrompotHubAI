import { Skeleton } from "@/components/ui/skeleton";

export default function Loading() {
  return (
    <div className="container max-w-3xl py-10">
      <Skeleton className="mb-6 h-4 w-32" />
      <div className="mb-6 flex items-start gap-4">
        <Skeleton className="h-12 w-12 rounded-xl" />
        <div className="flex-1">
          <Skeleton className="mb-2 h-7 w-3/4" />
          <Skeleton className="h-4 w-32" />
        </div>
      </div>
      <div className="mb-6 flex gap-2">
        <Skeleton className="h-6 w-24 rounded-full" />
        <Skeleton className="h-6 w-24 rounded-full" />
        <Skeleton className="h-6 w-24 rounded-full" />
      </div>
      <Skeleton className="mb-8 h-16 w-full" />
      <Skeleton className="h-64 w-full rounded-xl" />
    </div>
  );
}
