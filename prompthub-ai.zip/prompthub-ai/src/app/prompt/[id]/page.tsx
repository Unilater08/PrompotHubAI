import { notFound } from "next/navigation";
import Link from "next/link";
import { ChevronLeft, Clock, BarChart3, Bot } from "lucide-react";
import { createClient } from "@/services/supabase/server";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { PromptContent } from "@/components/prompts/prompt-content";
import { getCategoryIcon } from "@/utils/icons";
import { formatNivel, nivelColor } from "@/utils/format";
import type { Prompt } from "@/types";
import type { Metadata } from "next";

async function getPrompt(id: string) {
  const supabase = createClient();
  const { data } = await supabase
    .from("prompts")
    .select("*, category:categories(*)")
    .eq("id", id)
    .single();
  return data as unknown as Prompt | null;
}

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
  const prompt = await getPrompt(params.id);
  if (!prompt) return { title: "Prompt não encontrado — PromptHub AI" };
  return {
    title: `${prompt.titulo} — PromptHub AI`,
    description: prompt.descricao,
  };
}

export default async function PromptPage({ params }: { params: { id: string } }) {
  const prompt = await getPrompt(params.id);
  if (!prompt) return notFound();

  const Icon = getCategoryIcon(prompt.category?.icone ?? "zap");

  return (
    <div className="container max-w-3xl animate-fade-in py-10">
      <Link href="/dashboard" className="mb-6 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ChevronLeft className="h-4 w-4" /> Voltar para prompts
      </Link>

      <div className="mb-6 flex items-start gap-4">
        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <Icon className="h-6 w-6" />
        </span>
        <div>
          <h1 className="font-display text-2xl font-semibold leading-tight tracking-tight sm:text-3xl">
            {prompt.titulo}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">{prompt.category?.nome}</p>
        </div>
      </div>

      <div className="mb-6 flex flex-wrap items-center gap-2">
        <Badge variant="muted" className={nivelColor(prompt.nivel)}>
          <BarChart3 className="mr-1 h-3 w-3" /> {formatNivel(prompt.nivel)}
        </Badge>
        <Badge variant="secondary">
          <Bot className="mr-1 h-3 w-3" /> {prompt.tipo_ia}
        </Badge>
        <Badge variant="secondary">
          <Clock className="mr-1 h-3 w-3" /> {prompt.tempo_leitura} min de leitura
        </Badge>
      </div>

      <p className="mb-8 text-base leading-relaxed text-muted-foreground">{prompt.descricao}</p>

      <PromptContent promptId={prompt.id} conteudo={prompt.conteudo} />

      {prompt.tags?.length > 0 && (
        <div className="mt-6 flex flex-wrap gap-2">
          {prompt.tags.map((tag) => (
            <Badge key={tag} variant="outline">
              #{tag}
            </Badge>
          ))}
        </div>
      )}

      {prompt.exemplo_resultado && (
        <Card className="mt-8">
          <CardContent className="pt-6">
            <h2 className="mb-3 font-display text-sm font-semibold tracking-tight">Exemplo de resultado</h2>
            <p className="whitespace-pre-wrap text-sm leading-relaxed text-muted-foreground">
              {prompt.exemplo_resultado}
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
