import Link from "next/link";
import { ArrowRight, Sparkles } from "lucide-react";
import { createClient } from "@/services/supabase/server";
import { Button } from "@/components/ui/button";
import { CategoryCard } from "@/components/categories/category-card";
import { PromptCard } from "@/components/prompts/prompt-card";
import { HomeSearch } from "@/components/prompts/home-search";
import type { Category, Prompt } from "@/types";

export const revalidate = 60;

async function getHomeData() {
  const supabase = createClient();

  const [{ data: categories }, { data: popular }, { data: recent }] = await Promise.all([
    supabase.from("categories").select("*").order("nome"),
    supabase
      .from("prompts")
      .select("*, category:categories(*)")
      .order("copy_count", { ascending: false })
      .limit(6),
    supabase
      .from("prompts")
      .select("*, category:categories(*)")
      .order("created_at", { ascending: false })
      .limit(6),
  ]);

  return {
    categories: (categories ?? []) as Category[],
    popular: (popular ?? []) as unknown as Prompt[],
    recent: (recent ?? []) as unknown as Prompt[],
  };
}

export default async function HomePage() {
  const { categories, popular, recent } = await getHomeData();

  return (
    <div className="animate-fade-in">
      {/* Hero */}
      <section className="container flex flex-col items-center gap-6 py-20 text-center sm:py-28">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary px-3 py-1 text-xs font-medium text-muted-foreground">
          <Sparkles className="h-3.5 w-3.5 text-primary" />
          Mais de {popular.length + recent.length}+ prompts testados
        </span>
        <h1 className="max-w-2xl font-display text-4xl font-semibold leading-[1.1] tracking-tight sm:text-5xl">
          Encontre o prompt <span className="text-primary">perfeito</span> em segundos.
        </h1>
        <p className="max-w-lg text-balance text-base text-muted-foreground sm:text-lg">
          Uma biblioteca curada de prompts prontos para ChatGPT, Claude, Gemini e Midjourney. Pesquise, copie e use agora mesmo.
        </p>

        <HomeSearch />

        <Button size="lg" asChild className="mt-2 rounded-xl">
          <Link href="/dashboard">
            Começar agora <ArrowRight className="h-4 w-4" />
          </Link>
        </Button>
      </section>

      {/* Categorias */}
      <section className="container py-12">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="font-display text-xl font-semibold tracking-tight">Categorias</h2>
          <Link href="/categorias" className="text-sm font-medium text-primary hover:underline">
            Ver todas
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {categories.map((category) => (
            <CategoryCard key={category.id} category={category} />
          ))}
        </div>
      </section>

      {/* Populares */}
      <section className="container py-12">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="font-display text-xl font-semibold tracking-tight">Prompts populares</h2>
          <Link href="/dashboard" className="text-sm font-medium text-primary hover:underline">
            Ver todos
          </Link>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {popular.map((prompt) => (
            <PromptCard key={prompt.id} prompt={prompt} />
          ))}
        </div>
      </section>

      {/* Recentes */}
      <section className="container py-12 pb-24">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="font-display text-xl font-semibold tracking-tight">Últimos adicionados</h2>
          <Link href="/dashboard" className="text-sm font-medium text-primary hover:underline">
            Ver todos
          </Link>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {recent.map((prompt) => (
            <PromptCard key={prompt.id} prompt={prompt} />
          ))}
        </div>
      </section>
    </div>
  );
}
