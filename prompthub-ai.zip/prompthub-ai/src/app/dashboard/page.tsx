"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AlertTriangle, Loader2 } from "lucide-react";
import { SearchBar } from "@/components/prompts/search-bar";
import { PromptFiltersBar } from "@/components/prompts/prompt-filters-bar";
import { PromptGrid } from "@/components/prompts/prompt-grid";
import { Button } from "@/components/ui/button";
import { usePrompts } from "@/hooks/use-prompts";
import { useCategories } from "@/hooks/use-categories";
import { useDebounce } from "@/hooks/use-debounce";
import type { PromptFilters } from "@/types";

function DashboardContent() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") ?? "";

  const [search, setSearch] = useState(initialQuery);
  const [filters, setFilters] = useState<PromptFilters>({});
  const debouncedSearch = useDebounce(search, 300);
  const { categories } = useCategories();
  const { prompts, count, loading, loadingMore, hasMore, error, loadMore } = usePrompts({
    ...filters,
    search: debouncedSearch,
  });

  useEffect(() => {
    setSearch(initialQuery);
  }, [initialQuery]);

  return (
    <div className="container animate-fade-in py-10">
      <div className="mb-8 flex flex-col gap-2">
        <h1 className="font-display text-2xl font-semibold tracking-tight">Explorar prompts</h1>
        <p className="text-sm text-muted-foreground" aria-live="polite">
          {loading
            ? "Buscando…"
            : `${count} prompt${count === 1 ? "" : "s"} encontrado${count === 1 ? "" : "s"}`}
        </p>
      </div>

      <div className="mb-6 flex flex-col gap-4">
        <SearchBar value={search} onChange={setSearch} size="lg" />
        <PromptFiltersBar categories={categories} filters={filters} onChange={setFilters} />
      </div>

      {error && (
        <div
          role="alert"
          className="mb-6 flex items-center gap-3 rounded-lg border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive"
        >
          <AlertTriangle className="h-4 w-4 shrink-0" />
          <span>
            Não foi possível carregar os prompts agora. {error} Verifique sua conexão e tente novamente.
          </span>
        </div>
      )}

      <PromptGrid prompts={prompts} loading={loading} />

      {!loading && hasMore && (
        <div className="mt-8 flex justify-center">
          <Button variant="outline" onClick={loadMore} disabled={loadingMore}>
            {loadingMore && <Loader2 className="h-4 w-4 animate-spin" />}
            Carregar mais prompts
          </Button>
        </div>
      )}
    </div>
  );
}

export default function DashboardPage() {
  return (
    <Suspense>
      <DashboardContent />
    </Suspense>
  );
}
