import { createClient } from "@/services/supabase/server";
import { CategoryCard } from "@/components/categories/category-card";
import type { Category } from "@/types";

export const revalidate = 60;

/**
 * Correção (auditoria 06/2026): a versão anterior buscava a coluna
 * `categoria_id` de TODAS as linhas da tabela `prompts` só para contar
 * quantas pertencem a cada categoria em JavaScript. Com 1.000.000 de
 * prompts isso seria uma transferência e um processamento gigantes a cada
 * acesso. Agora cada contagem é feita no próprio banco (`count: "exact",
 * head: true`), uma consulta leve por categoria, em paralelo.
 */
async function getCategoriesWithCount() {
  const supabase = createClient();
  const { data: categories } = await supabase.from("categories").select("*").order("nome");

  const categoryList = (categories ?? []) as Category[];

  const counts = await Promise.all(
    categoryList.map(async (category) => {
      const { count } = await supabase
        .from("prompts")
        .select("id", { count: "exact", head: true })
        .eq("categoria_id", category.id);
      return [category.id, count ?? 0] as const;
    })
  );

  return { categories: categoryList, counts: new Map(counts) };
}

export default async function CategoriasPage() {
  const { categories, counts } = await getCategoriesWithCount();

  return (
    <div className="container animate-fade-in py-10">
      <div className="mb-8">
        <h1 className="font-display text-2xl font-semibold tracking-tight">Categorias</h1>
        <p className="text-sm text-muted-foreground">
          Explore prompts organizados por área de uso.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {categories.map((category) => (
          <CategoryCard key={category.id} category={category} count={counts.get(category.id) ?? 0} />
        ))}
      </div>
    </div>
  );
}
