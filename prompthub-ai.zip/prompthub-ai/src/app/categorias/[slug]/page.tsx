import { notFound } from "next/navigation";
import Link from "next/link";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { createClient } from "@/services/supabase/server";
import { PromptCard } from "@/components/prompts/prompt-card";
import { Button } from "@/components/ui/button";
import { getCategoryIcon } from "@/utils/icons";
import type { Category, Prompt } from "@/types";

export const revalidate = 60;

const PAGE_SIZE = 24;

/**
 * Correção (auditoria 06/2026): a versão anterior buscava TODOS os prompts
 * de uma categoria de uma vez, sem nenhum limite — inviável quando uma
 * categoria tiver milhares de prompts. Agora a página é paginada via
 * `?page=`, com `.range()` no banco e contagem exata via `count: "exact"`.
 */
async function getCategoryData(slug: string, page: number) {
  const supabase = createClient();
  const { data: category } = await supabase.from("categories").select("*").eq("slug", slug).single();
  if (!category) return null;

  const from = (page - 1) * PAGE_SIZE;
  const to = from + PAGE_SIZE - 1;

  const { data: prompts, count } = await supabase
    .from("prompts")
    .select("*, category:categories(*)", { count: "exact" })
    .eq("categoria_id", category.id)
    .order("created_at", { ascending: false })
    .range(from, to);

  return {
    category: category as Category,
    prompts: (prompts ?? []) as unknown as Prompt[],
    total: count ?? 0,
  };
}

export default async function CategoriaSlugPage({
  params,
  searchParams,
}: {
  params: { slug: string };
  searchParams: { page?: string };
}) {
  const page = Math.max(1, Number(searchParams.page) || 1);
  const data = await getCategoryData(params.slug, page);
  if (!data) return notFound();

  const { category, prompts, total } = data;
  const Icon = getCategoryIcon(category.icone);
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div className="container animate-fade-in py-10">
      <Link href="/categorias" className="mb-6 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ChevronLeft className="h-4 w-4" /> Categorias
      </Link>

      <div className="mb-8 flex items-center gap-4">
        <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <Icon className="h-6 w-6" />
        </span>
        <div>
          <h1 className="font-display text-2xl font-semibold tracking-tight">{category.nome}</h1>
          <p className="text-sm text-muted-foreground">
            {total} prompt{total === 1 ? "" : "s"} disponível{total === 1 ? "" : "is"}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {prompts.map((prompt) => (
          <PromptCard key={prompt.id} prompt={prompt} />
        ))}
      </div>

      {totalPages > 1 && (
        <div className="mt-10 flex items-center justify-center gap-3">
          <Button variant="outline" size="sm" disabled={page <= 1} asChild={page > 1}>
            {page > 1 ? (
              <Link href={`/categorias/${category.slug}?page=${page - 1}`}>
                <ChevronLeft className="h-4 w-4" /> Anterior
              </Link>
            ) : (
              <span>
                <ChevronLeft className="h-4 w-4" /> Anterior
              </span>
            )}
          </Button>
          <span className="text-sm text-muted-foreground">
            Página {page} de {totalPages}
          </span>
          <Button variant="outline" size="sm" disabled={page >= totalPages} asChild={page < totalPages}>
            {page < totalPages ? (
              <Link href={`/categorias/${category.slug}?page=${page + 1}`}>
                Próxima <ChevronRight className="h-4 w-4" />
              </Link>
            ) : (
              <span>
                Próxima <ChevronRight className="h-4 w-4" />
              </span>
            )}
          </Button>
        </div>
      )}
    </div>
  );
}
