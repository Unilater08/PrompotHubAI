import type { MetadataRoute } from "next";
import { createClient } from "@/services/supabase/server";

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

// Correção (auditoria 06/2026): a aplicação não tinha sitemap nenhum, o que
// prejudica a indexação em escala (1M de prompts não seriam descobertos
// pelos buscadores apenas via navegação). Buscamos em páginas para não
// estourar o limite padrão de linhas do PostgREST mesmo com o catálogo
// crescendo bastante.
async function getAllSlugsAndIds() {
  const supabase = createClient();
  const pageSize = 1000;

  const categories: { slug: string }[] = [];
  const prompts: { id: string; created_at: string }[] = [];

  const { data: categoryRows } = await supabase.from("categories").select("slug");
  categories.push(...(categoryRows ?? []));

  let from = 0;
  // Limite de segurança para não gerar um sitemap gigante em uma única
  // resposta; para catálogos muito grandes, prefira sitemaps paginados
  // (sitemap-0.xml, sitemap-1.xml, ...).
  const MAX_PAGES = 20;

  for (let pageIndex = 0; pageIndex < MAX_PAGES; pageIndex++) {
    const { data } = await supabase
      .from("prompts")
      .select("id, created_at")
      .order("created_at", { ascending: false })
      .range(from, from + pageSize - 1);

    if (!data || data.length === 0) break;
    prompts.push(...data);
    if (data.length < pageSize) break;
    from += pageSize;
  }

  return { categories, prompts };
}

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const { categories, prompts } = await getAllSlugsAndIds();

  const staticRoutes: MetadataRoute.Sitemap = [
    { url: `${SITE_URL}/`, changeFrequency: "daily", priority: 1 },
    { url: `${SITE_URL}/dashboard`, changeFrequency: "daily", priority: 0.9 },
    { url: `${SITE_URL}/categorias`, changeFrequency: "weekly", priority: 0.7 },
  ];

  const categoryRoutes: MetadataRoute.Sitemap = categories.map((category) => ({
    url: `${SITE_URL}/categorias/${category.slug}`,
    changeFrequency: "weekly",
    priority: 0.6,
  }));

  const promptRoutes: MetadataRoute.Sitemap = prompts.map((prompt) => ({
    url: `${SITE_URL}/prompt/${prompt.id}`,
    lastModified: prompt.created_at,
    changeFrequency: "monthly",
    priority: 0.5,
  }));

  return [...staticRoutes, ...categoryRoutes, ...promptRoutes];
}
