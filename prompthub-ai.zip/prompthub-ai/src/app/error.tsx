"use client";

import { useEffect } from "react";
import Link from "next/link";
import { AlertTriangle, RotateCw } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ErrorBoundary({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    // Em produção, troque por uma ferramenta de observabilidade (ex: Sentry).
    // eslint-disable-next-line no-console
    console.error("Erro não tratado na aplicação:", error);
  }, [error]);

  return (
    <div className="container flex min-h-[60vh] flex-col items-center justify-center gap-4 text-center">
      <span className="flex h-14 w-14 items-center justify-center rounded-full bg-destructive/10 text-destructive">
        <AlertTriangle className="h-6 w-6" />
      </span>
      <h1 className="font-display text-2xl font-semibold tracking-tight">Algo deu errado</h1>
      <p className="max-w-sm text-sm text-muted-foreground">
        Não foi possível carregar esta página. Você pode tentar novamente ou voltar para os prompts.
      </p>
      <div className="flex gap-3">
        <Button onClick={reset}>
          <RotateCw className="h-4 w-4" /> Tentar novamente
        </Button>
        <Button variant="outline" asChild>
          <Link href="/dashboard">Voltar para prompts</Link>
        </Button>
      </div>
    </div>
  );
}
