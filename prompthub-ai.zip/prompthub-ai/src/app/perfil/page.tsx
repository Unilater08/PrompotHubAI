"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { LogOut, Mail, User as UserIcon, Copy, Crown } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { signOut } from "@/services/auth.service";
import { getUserCopyCount } from "@/services/history.service";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { getInitials } from "@/utils/format";

export default function PerfilPage() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const router = useRouter();
  const [copyCount, setCopyCount] = useState<number | null>(null);

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      router.push("/login");
    }
  }, [authLoading, isAuthenticated, router]);

  useEffect(() => {
    if (user) {
      getUserCopyCount(user.id).then(setCopyCount);
    }
  }, [user]);

  async function handleLogout() {
    await signOut();
    router.push("/");
    router.refresh();
  }

  if (authLoading || !user) {
    return (
      <div className="container max-w-xl py-10">
        <Skeleton className="h-48 w-full rounded-xl" />
      </div>
    );
  }

  const nome = (user.user_metadata?.nome as string) ?? user.email ?? "Usuário";

  return (
    <div className="container max-w-xl animate-fade-in py-10">
      <h1 className="mb-6 font-display text-2xl font-semibold tracking-tight">Meu perfil</h1>

      <Card>
        <CardHeader className="flex-row items-center gap-4 space-y-0">
          <Avatar className="h-16 w-16">
            <AvatarImage src={(user.user_metadata?.avatar_url as string) ?? undefined} alt={nome} />
            <AvatarFallback className="text-lg">{getInitials(nome)}</AvatarFallback>
          </Avatar>
          <div>
            <CardTitle>{nome}</CardTitle>
            <p className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <Mail className="h-3.5 w-3.5" /> {user.email}
            </p>
          </div>
        </CardHeader>
        <CardContent className="grid gap-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="rounded-lg border border-border p-4">
              <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Copy className="h-3.5 w-3.5" /> Prompts copiados
              </p>
              <p className="mt-1 font-display text-2xl font-semibold">
                {copyCount === null ? "—" : copyCount}
              </p>
            </div>
            <div className="rounded-lg border border-border p-4">
              <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Crown className="h-3.5 w-3.5" /> Plano atual
              </p>
              <p className="mt-1 font-display text-2xl font-semibold">Gratuito</p>
            </div>
          </div>

          <div className="flex items-center gap-2 rounded-lg border border-dashed border-border p-4 text-sm text-muted-foreground">
            <UserIcon className="h-4 w-4 shrink-0" />
            Seu histórico de prompts copiados é salvo automaticamente na sua conta.
          </div>

          <Button variant="outline" onClick={handleLogout} className="text-destructive hover:text-destructive">
            <LogOut className="h-4 w-4" /> Sair da conta
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
