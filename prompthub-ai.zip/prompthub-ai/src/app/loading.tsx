import { Skeleton } from "@/components/ui/skeleton";

export default function Loading() {
  return (
    <div className="container animate-fade-in py-20">
      <div className="mx-auto flex max-w-xl flex-col items-center gap-4">
        <Skeleton className="h-6 w-40 rounded-full" />
        <Skeleton className="h-10 w-full max-w-md" />
        <Skeleton className="h-4 w-3/4" />
        <Skeleton className="mt-2 h-14 w-full max-w-xl rounded-2xl" />
      </div>
      <div className="mt-16 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-24 w-full rounded-xl" />
        ))}
      </div>
    </div>
  );
}
