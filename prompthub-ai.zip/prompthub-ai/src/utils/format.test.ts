import { describe, expect, it } from "vitest";
import { formatNivel, getInitials, truncate } from "@/utils/format";

describe("formatNivel", () => {
  it("traduz os níveis corretamente", () => {
    expect(formatNivel("iniciante")).toBe("Iniciante");
    expect(formatNivel("intermediario")).toBe("Intermediário");
    expect(formatNivel("avancado")).toBe("Avançado");
  });
});

describe("truncate", () => {
  it("não altera textos menores que o limite", () => {
    expect(truncate("texto curto", 100)).toBe("texto curto");
  });

  it("corta e adiciona reticências em textos longos", () => {
    const longo = "a".repeat(150);
    const resultado = truncate(longo, 110);
    expect(resultado.endsWith("…")).toBe(true);
    expect(resultado.length).toBeLessThanOrEqual(112);
  });
});

describe("getInitials", () => {
  it("retorna as iniciais de até dois nomes", () => {
    expect(getInitials("Maria Silva")).toBe("MS");
    expect(getInitials("João")).toBe("J");
    expect(getInitials("Ana Maria Souza")).toBe("AM");
  });
});
