import {
  Megaphone,
  Instagram,
  MessageCircle,
  ShoppingCart,
  Briefcase,
  Headphones,
  Code2,
  FileSpreadsheet,
  GraduationCap,
  Zap,
  type LucideIcon,
} from "lucide-react";

export const categoryIcons: Record<string, LucideIcon> = {
  megaphone: Megaphone,
  instagram: Instagram,
  "message-circle": MessageCircle,
  "shopping-cart": ShoppingCart,
  briefcase: Briefcase,
  headphones: Headphones,
  code: Code2,
  sheet: FileSpreadsheet,
  "graduation-cap": GraduationCap,
  zap: Zap,
};

export function getCategoryIcon(icone: string): LucideIcon {
  return categoryIcons[icone] ?? Zap;
}
