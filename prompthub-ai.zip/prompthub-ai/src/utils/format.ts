import type { Nivel } from "@/types";

export function formatNivel(nivel: Nivel): string {
  const map: Record<Nivel, string> = {
    iniciante: "Iniciante",
    intermediario: "Intermediário",
    avancado: "Avançado",
  };
  return map[nivel];
}

export function nivelColor(nivel: Nivel): string {
  const map: Record<Nivel, string> = {
    iniciante: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
    intermediario: "bg-amber-500/10 text-amber-600 dark:text-amber-400",
    avancado: "bg-rose-500/10 text-rose-600 dark:text-rose-400",
  };
  return map[nivel];
}

export function formatRelativeDate(dateStr: string): string {
  const date = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (diffDays === 0) return "Hoje";
  if (diffDays === 1) return "Ontem";
  if (diffDays < 7) return `Há ${diffDays} dias`;
  if (diffDays < 30) return `Há ${Math.floor(diffDays / 7)} semanas`;
  return date.toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "numeric" });
}

export function truncate(text: string, max = 110): string {
  if (text.length <= max) return text;
  return `${text.slice(0, max).trim()}…`;
}

export function getInitials(name: string): string {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
}
