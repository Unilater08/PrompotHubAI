/**
 * Script de seed do PromptHub AI.
 * Roda com: npm run seed
 * Necessita SUPABASE_SERVICE_ROLE_KEY no .env (nunca exponha essa chave no client).
 */
import "dotenv/config";
import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
  console.error(
    "❌ Defina NEXT_PUBLIC_SUPABASE_URL e SUPABASE_SERVICE_ROLE_KEY no arquivo .env antes de rodar o seed."
  );
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

type CategorySeed = { nome: string; slug: string; icone: string; descricao: string };

const categories: CategorySeed[] = [
  { nome: "Marketing", slug: "marketing", icone: "megaphone", descricao: "Campanhas, anúncios e estratégias de marketing." },
  { nome: "Instagram", slug: "instagram", icone: "instagram", descricao: "Legendas, bios e conteúdo para Instagram." },
  { nome: "WhatsApp", slug: "whatsapp", icone: "message-circle", descricao: "Mensagens e scripts de atendimento via WhatsApp." },
  { nome: "Vendas", slug: "vendas", icone: "shopping-cart", descricao: "Discursos, follow-ups e fechamento de vendas." },
  { nome: "Negócios", slug: "negocios", icone: "briefcase", descricao: "Planejamento estratégico e gestão de negócios." },
  { nome: "Atendimento", slug: "atendimento", icone: "headphones", descricao: "Suporte e relacionamento com o cliente." },
  { nome: "Programação", slug: "programacao", icone: "code", descricao: "Código, debugging e documentação técnica." },
  { nome: "Excel", slug: "excel", icone: "sheet", descricao: "Fórmulas, planilhas e automações no Excel." },
  { nome: "Estudos", slug: "estudos", icone: "graduation-cap", descricao: "Resumos, planos de estudo e revisão de conteúdo." },
  { nome: "Produtividade", slug: "produtividade", icone: "zap", descricao: "Organização, rotinas e gestão do tempo." },
];

type Nivel = "iniciante" | "intermediario" | "avancado";

type PromptSeed = {
  titulo: string;
  descricao: string;
  conteudo: string;
  categoriaSlug: string;
  nivel: Nivel;
  tipo_ia: string;
  tags: string[];
  tempo_leitura: number;
  exemplo_resultado: string;
};

const prompts: PromptSeed[] = [
  // ---------------- MARKETING ----------------
  {
    titulo: "Plano de campanha de marketing completo",
    descricao: "Cria um plano de campanha de marketing do zero, com objetivos, canais e cronograma.",
    conteudo: "Atue como um estrategista de marketing sênior. Crie um plano de campanha completo para [PRODUTO/SERVIÇO], direcionado a [PÚBLICO-ALVO], com orçamento de [VALOR]. Inclua: objetivos SMART, canais recomendados, calendário de 30 dias, mensagens-chave por etapa do funil e métricas de sucesso.",
    categoriaSlug: "marketing",
    nivel: "intermediario",
    tipo_ia: "ChatGPT",
    tags: ["campanha", "estrategia", "funil"],
    tempo_leitura: 3,
    exemplo_resultado: "Plano de 30 dias dividido em Awareness, Consideração e Conversão, com 3 canais prioritários e KPIs por fase.",
  },
  {
    titulo: "Gerador de slogans de marca",
    descricao: "Gera 10 opções de slogan curtos e memoráveis para uma marca.",
    conteudo: "Crie 10 slogans curtos e impactantes para a marca [NOME DA MARCA], que atua no segmento de [SEGMENTO]. Os slogans devem transmitir [VALOR PRINCIPAL] e ter no máximo 6 palavras cada.",
    categoriaSlug: "marketing",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["branding", "slogan", "copywriting"],
    tempo_leitura: 1,
    exemplo_resultado: "\"Simples. Rápido. Seu.\" — entre outras 9 variações com diferentes tons.",
  },
  {
    titulo: "Análise SWOT automática",
    descricao: "Realiza uma análise SWOT estruturada para um produto ou empresa.",
    conteudo: "Faça uma análise SWOT detalhada para [EMPRESA/PRODUTO]. Considere o mercado [MERCADO/NICHO] e os concorrentes [LISTA DE CONCORRENTES]. Organize em quatro seções: Forças, Fraquezas, Oportunidades e Ameaças, com 4 pontos em cada.",
    categoriaSlug: "marketing",
    nivel: "intermediario",
    tipo_ia: "Claude",
    tags: ["swot", "analise", "estrategia"],
    tempo_leitura: 2,
    exemplo_resultado: "Tabela com 4 forças, 4 fraquezas, 4 oportunidades e 4 ameaças, cada uma com uma justificativa de uma linha.",
  },
  {
    titulo: "Briefing de criativo para anúncios",
    descricao: "Estrutura um briefing claro para a equipe de criação de anúncios.",
    conteudo: "Crie um briefing de criativo para um anúncio de [PRODUTO], destinado à plataforma [INSTAGRAM/FACEBOOK/GOOGLE ADS]. Inclua: objetivo da campanha, público-alvo, tom de voz, mensagem principal, CTA e referências visuais sugeridas.",
    categoriaSlug: "marketing",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["anuncios", "briefing", "ads"],
    tempo_leitura: 2,
    exemplo_resultado: "Briefing de uma página com objetivo, público, tom de voz e 3 referências visuais.",
  },
  {
    titulo: "Imagem de anúncio estilo minimalista",
    descricao: "Gera o prompt visual para criar uma imagem de anúncio minimalista e moderna.",
    conteudo: "Crie uma imagem publicitária minimalista para [PRODUTO], fundo liso na cor [COR], iluminação suave de estúdio, composição centrada, estilo clean, alta resolução, sem texto, proporção 4:5, estética premium e moderna.",
    categoriaSlug: "marketing",
    nivel: "avancado",
    tipo_ia: "Midjourney",
    tags: ["imagem", "anuncio", "design"],
    tempo_leitura: 1,
    exemplo_resultado: "Imagem com o produto centralizado, fundo em cor sólida e iluminação suave, pronta para uso em redes sociais.",
  },

  // ---------------- INSTAGRAM ----------------
  {
    titulo: "Legenda para post de produto",
    descricao: "Cria uma legenda persuasiva para divulgar um produto no Instagram.",
    conteudo: "Escreva uma legenda envolvente para um post no Instagram divulgando [PRODUTO]. Use um gancho nas primeiras 2 linhas, destaque 3 benefícios, finalize com uma chamada para ação clara e sugira 5 hashtags relevantes.",
    categoriaSlug: "instagram",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["legenda", "instagram", "copywriting"],
    tempo_leitura: 1,
    exemplo_resultado: "Legenda de 4 parágrafos curtos com gancho, benefícios, CTA e hashtags ao final.",
  },
  {
    titulo: "Bio de Instagram otimizada",
    descricao: "Cria uma bio curta e estratégica para perfil pessoal ou de negócio.",
    conteudo: "Crie 3 opções de bio para o Instagram de [NOME/MARCA], que atua em [NICHO]. A bio deve ter no máximo 150 caracteres, comunicar valor claro e incluir uma chamada para ação para o link na bio.",
    categoriaSlug: "instagram",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["bio", "perfil", "instagram"],
    tempo_leitura: 1,
    exemplo_resultado: "3 versões de bio, cada uma com até 150 caracteres e uma CTA final.",
  },
  {
    titulo: "Calendário de conteúdo para 30 dias",
    descricao: "Monta um calendário editorial completo de 30 dias para o Instagram.",
    conteudo: "Crie um calendário de conteúdo de 30 dias para o Instagram de uma marca de [NICHO]. Para cada dia, indique o formato (Reels, Carrossel, Story ou Post estático), o tema e um título sugerido.",
    categoriaSlug: "instagram",
    nivel: "intermediario",
    tipo_ia: "ChatGPT",
    tags: ["calendario", "planejamento", "conteudo"],
    tempo_leitura: 3,
    exemplo_resultado: "Tabela com 30 linhas, cada uma com data, formato, tema e título do conteúdo.",
  },
  {
    titulo: "Roteiro de Reels virais",
    descricao: "Cria um roteiro curto e dinâmico para um Reels com potencial de viralização.",
    conteudo: "Escreva um roteiro de 30 segundos para um Reels sobre [TEMA], com gancho nos primeiros 3 segundos, 3 cortes de cena e uma frase final de impacto. Indique também a trilha sonora sugerida.",
    categoriaSlug: "instagram",
    nivel: "intermediario",
    tipo_ia: "ChatGPT",
    tags: ["reels", "video", "roteiro"],
    tempo_leitura: 2,
    exemplo_resultado: "Roteiro dividido em 4 cenas com tempo, fala e direção de câmera para cada uma.",
  },
  {
    titulo: "Imagem de capa para carrossel",
    descricao: "Gera o prompt visual para a capa de um carrossel educativo no Instagram.",
    conteudo: "Crie uma imagem de capa para carrossel do Instagram sobre [TEMA], estilo flat design, paleta de cores [CORES], tipografia bold, espaço reservado para o título no centro, proporção 4:5, visual moderno e clean.",
    categoriaSlug: "instagram",
    nivel: "avancado",
    tipo_ia: "DALL-E",
    tags: ["carrossel", "design", "imagem"],
    tempo_leitura: 1,
    exemplo_resultado: "Capa em flat design com espaço central para o título e paleta de cores consistente com a marca.",
  },

  // ---------------- WHATSAPP ----------------
  {
    titulo: "Mensagem de boas-vindas automática",
    descricao: "Cria uma mensagem de boas-vindas calorosa para novos contatos no WhatsApp Business.",
    conteudo: "Escreva uma mensagem de boas-vindas para o WhatsApp Business de [EMPRESA]. Deve ser amigável, breve, apresentar o que a empresa faz e perguntar como pode ajudar o cliente.",
    categoriaSlug: "whatsapp",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["boas-vindas", "atendimento", "whatsapp"],
    tempo_leitura: 1,
    exemplo_resultado: "Mensagem de 3 linhas com saudação, apresentação da empresa e pergunta de abertura.",
  },
  {
    titulo: "Script de follow-up para carrinho abandonado",
    descricao: "Recupera vendas com uma mensagem de follow-up educada e persuasiva.",
    conteudo: "Crie uma mensagem de WhatsApp para recuperar um carrinho abandonado de [PRODUTO]. O tom deve ser amigável, sem pressão, oferecendo ajuda para finalizar a compra e mencionando um benefício de agir agora.",
    categoriaSlug: "whatsapp",
    nivel: "intermediario",
    tipo_ia: "ChatGPT",
    tags: ["vendas", "follow-up", "recuperacao"],
    tempo_leitura: 1,
    exemplo_resultado: "Mensagem curta perguntando se o cliente teve dúvidas, com um lembrete gentil sobre o item no carrinho.",
  },
  {
    titulo: "Respostas rápidas para dúvidas frequentes",
    descricao: "Gera um conjunto de respostas rápidas para as perguntas mais comuns dos clientes.",
    conteudo: "Crie 8 respostas rápidas e objetivas para o WhatsApp Business de [EMPRESA], cobrindo as perguntas mais comuns sobre: prazo de entrega, formas de pagamento, trocas e devoluções, e horário de atendimento.",
    categoriaSlug: "whatsapp",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["faq", "respostas-rapidas", "suporte"],
    tempo_leitura: 2,
    exemplo_resultado: "Lista com 8 respostas curtas, cada uma identificada pelo tema da pergunta.",
  },
  {
    titulo: "Script de qualificação de leads",
    descricao: "Cria um roteiro de perguntas para qualificar leads recebidos via WhatsApp.",
    conteudo: "Monte um script de qualificação de leads para o WhatsApp, com 5 perguntas estratégicas para entender a necessidade, orçamento e urgência do cliente interessado em [PRODUTO/SERVIÇO].",
    categoriaSlug: "whatsapp",
    nivel: "intermediario",
    tipo_ia: "Claude",
    tags: ["leads", "qualificacao", "vendas"],
    tempo_leitura: 2,
    exemplo_resultado: "5 perguntas em ordem lógica, da necessidade até o orçamento disponível.",
  },
  {
    titulo: "Mensagem de cobrança educada",
    descricao: "Cria uma mensagem de cobrança firme, porém respeitosa, para clientes em atraso.",
    conteudo: "Escreva uma mensagem de cobrança para um cliente com pagamento em atraso de [VALOR] referente a [PRODUTO/SERVIÇO]. O tom deve ser educado e profissional, sem soar agressivo, oferecendo facilidade para regularização.",
    categoriaSlug: "whatsapp",
    nivel: "intermediario",
    tipo_ia: "ChatGPT",
    tags: ["cobranca", "financeiro", "atendimento"],
    tempo_leitura: 1,
    exemplo_resultado: "Mensagem de 3 a 4 linhas, cordial, lembrando o valor em aberto e oferecendo opções de pagamento.",
  },

  // ---------------- VENDAS ----------------
  {
    titulo: "Script de vendas consultivas",
    descricao: "Cria um roteiro de vendas baseado em perguntas consultivas e não em pressão.",
    conteudo: "Crie um script de vendas consultivas para [PRODUTO/SERVIÇO]. Estruture em 4 etapas: abertura, descoberta de necessidades (com perguntas abertas), apresentação da solução e fechamento. Evite jargões de vendas agressivas.",
    categoriaSlug: "vendas",
    nivel: "intermediario",
    tipo_ia: "ChatGPT",
    tags: ["script", "vendas", "consultivo"],
    tempo_leitura: 3,
    exemplo_resultado: "Script dividido em 4 blocos com exemplos de frases para cada etapa da conversa.",
  },
  {
    titulo: "Quebra de objeções de preço",
    descricao: "Gera respostas eficazes para quando o cliente diz que o preço está alto.",
    conteudo: "Liste 5 formas diferentes de responder quando um cliente diz que o preço de [PRODUTO/SERVIÇO] está alto, sem dar desconto imediato, focando em reforçar o valor entregue.",
    categoriaSlug: "vendas",
    nivel: "avancado",
    tipo_ia: "ChatGPT",
    tags: ["objecoes", "preco", "negociacao"],
    tempo_leitura: 2,
    exemplo_resultado: "5 respostas diferentes, cada uma com uma abordagem distinta (valor, comparação, ROI, etc).",
  },
  {
    titulo: "E-mail de proposta comercial",
    descricao: "Redige um e-mail profissional para enviar uma proposta comercial.",
    conteudo: "Escreva um e-mail de envio de proposta comercial para [CLIENTE], referente a [PRODUTO/SERVIÇO]. O e-mail deve ser objetivo, reforçar os principais benefícios e indicar os próximos passos para fechamento.",
    categoriaSlug: "vendas",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["proposta", "email", "b2b"],
    tempo_leitura: 2,
    exemplo_resultado: "E-mail com assunto, abertura cordial, resumo da proposta e CTA para uma chamada de fechamento.",
  },
  {
    titulo: "Pitch de vendas em 30 segundos",
    descricao: "Cria um discurso curto e direto para apresentar um produto rapidamente.",
    conteudo: "Crie um pitch de vendas de 30 segundos para [PRODUTO/SERVIÇO], destacando o problema que resolve, o diferencial competitivo e uma chamada para ação clara ao final.",
    categoriaSlug: "vendas",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["pitch", "elevator-pitch", "apresentacao"],
    tempo_leitura: 1,
    exemplo_resultado: "Parágrafo único com problema, solução, diferencial e CTA, lido em até 30 segundos.",
  },
  {
    titulo: "Análise de funil de vendas",
    descricao: "Avalia um funil de vendas existente e sugere melhorias por etapa.",
    conteudo: "Analise o funil de vendas a seguir: [DESCREVER ETAPAS DO FUNIL ATUAL]. Identifique possíveis gargalos em cada etapa e sugira 2 melhorias práticas por etapa para aumentar a taxa de conversão.",
    categoriaSlug: "vendas",
    nivel: "avancado",
    tipo_ia: "Claude",
    tags: ["funil", "conversao", "analise"],
    tempo_leitura: 3,
    exemplo_resultado: "Lista por etapa do funil com o gargalo identificado e 2 sugestões de melhoria.",
  },

  // ---------------- NEGÓCIOS ----------------
  {
    titulo: "Plano de negócio simplificado",
    descricao: "Estrutura um plano de negócio enxuto para validar uma ideia.",
    conteudo: "Crie um plano de negócio simplificado (modelo lean canvas) para a ideia de [NEGÓCIO]. Cubra: problema, solução, público-alvo, proposta de valor, canais, fontes de receita e principais custos.",
    categoriaSlug: "negocios",
    nivel: "intermediario",
    tipo_ia: "ChatGPT",
    tags: ["lean-canvas", "planejamento", "startup"],
    tempo_leitura: 3,
    exemplo_resultado: "Quadro com 7 blocos do lean canvas preenchidos com base na ideia apresentada.",
  },
  {
    titulo: "Análise de concorrência",
    descricao: "Compara a empresa com seus principais concorrentes de forma estruturada.",
    conteudo: "Compare [SUA EMPRESA] com os concorrentes [CONCORRENTE 1] e [CONCORRENTE 2]. Avalie preço, qualidade percebida, atendimento e diferenciais, organizando em uma tabela comparativa.",
    categoriaSlug: "negocios",
    nivel: "intermediario",
    tipo_ia: "Claude",
    tags: ["concorrencia", "analise", "mercado"],
    tempo_leitura: 2,
    exemplo_resultado: "Tabela comparativa com 4 critérios avaliados para cada concorrente.",
  },
  {
    titulo: "Precificação de produto ou serviço",
    descricao: "Ajuda a definir um preço justo considerando custos e percepção de valor.",
    conteudo: "Ajude a definir o preço de venda de [PRODUTO/SERVIÇO], considerando um custo de produção de [CUSTO], margem desejada de [MARGEM]% e o posicionamento de mercado [ECONÔMICO/PREMIUM]. Sugira 3 faixas de preço possíveis.",
    categoriaSlug: "negocios",
    nivel: "intermediario",
    tipo_ia: "ChatGPT",
    tags: ["precificacao", "financeiro", "estrategia"],
    tempo_leitura: 2,
    exemplo_resultado: "3 faixas de preço sugeridas, com a margem resultante de cada uma.",
  },
  {
    titulo: "Redação de missão, visão e valores",
    descricao: "Cria a declaração de missão, visão e valores de uma empresa.",
    conteudo: "Escreva a missão, visão e valores para a empresa [NOME], que atua no setor de [SETOR] com o propósito de [PROPÓSITO]. Cada item deve ter no máximo 2 frases.",
    categoriaSlug: "negocios",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["institucional", "missao", "valores"],
    tempo_leitura: 1,
    exemplo_resultado: "Três blocos curtos: missão, visão e de 3 a 5 valores listados.",
  },
  {
    titulo: "Relatório executivo mensal",
    descricao: "Estrutura um relatório executivo claro para apresentar resultados do mês.",
    conteudo: "Crie a estrutura de um relatório executivo mensal para apresentar aos sócios de [EMPRESA]. Inclua seções de: resumo executivo, principais resultados, desafios enfrentados e plano de ação para o próximo mês.",
    categoriaSlug: "negocios",
    nivel: "avancado",
    tipo_ia: "Claude",
    tags: ["relatorio", "gestao", "resultados"],
    tempo_leitura: 2,
    exemplo_resultado: "Relatório dividido em 4 seções, cada uma com bullet points objetivos.",
  },

  // ---------------- ATENDIMENTO ----------------
  {
    titulo: "Resposta a avaliação negativa",
    descricao: "Cria uma resposta profissional e empática para uma avaliação negativa online.",
    conteudo: "Escreva uma resposta para uma avaliação negativa de um cliente que reclamou sobre [MOTIVO DA RECLAMAÇÃO]. A resposta deve demonstrar empatia, assumir responsabilidade quando cabível e oferecer uma solução.",
    categoriaSlug: "atendimento",
    nivel: "intermediario",
    tipo_ia: "ChatGPT",
    tags: ["reclamacao", "reputacao", "resposta"],
    tempo_leitura: 1,
    exemplo_resultado: "Resposta de 3 a 4 linhas com pedido de desculpas, explicação e oferta de solução.",
  },
  {
    titulo: "Script de atendimento telefônico",
    descricao: "Cria um roteiro padrão para atendimento telefônico ao cliente.",
    conteudo: "Crie um script de atendimento telefônico para a equipe de suporte de [EMPRESA]. Inclua: saudação inicial, identificação do problema, confirmação do entendimento e encerramento cordial.",
    categoriaSlug: "atendimento",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["telefone", "script", "suporte"],
    tempo_leitura: 2,
    exemplo_resultado: "Script com 4 blocos de fala, do início ao encerramento da ligação.",
  },
  {
    titulo: "E-mail de desculpas por falha no serviço",
    descricao: "Redige um e-mail de desculpas formal após uma falha no atendimento ou entrega.",
    conteudo: "Escreva um e-mail de desculpas para um cliente que enfrentou [PROBLEMA] com [PRODUTO/SERVIÇO]. O tom deve ser sincero, sem excesso de formalidade, e deve incluir uma compensação ou próximo passo.",
    categoriaSlug: "atendimento",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["desculpas", "email", "cliente"],
    tempo_leitura: 1,
    exemplo_resultado: "E-mail curto com reconhecimento do problema, desculpas e uma solução concreta.",
  },
  {
    titulo: "Pesquisa de satisfação pós-atendimento",
    descricao: "Cria as perguntas de uma pesquisa de satisfação curta e eficaz.",
    conteudo: "Crie uma pesquisa de satisfação com 4 perguntas para enviar após o atendimento de um cliente de [EMPRESA]. Inclua uma pergunta de NPS (0 a 10) e 3 perguntas abertas sobre a experiência.",
    categoriaSlug: "atendimento",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["nps", "pesquisa", "satisfacao"],
    tempo_leitura: 1,
    exemplo_resultado: "Pesquisa com 1 pergunta de NPS e 3 perguntas abertas complementares.",
  },
  {
    titulo: "Manual de tom de voz para atendimento",
    descricao: "Define diretrizes de tom de voz para padronizar o atendimento da equipe.",
    conteudo: "Crie um guia de tom de voz para a equipe de atendimento de [EMPRESA], que deve transmitir [CARACTERÍSTICAS, ex: simpatia, agilidade, clareza]. Inclua exemplos de frases recomendadas e frases a evitar.",
    categoriaSlug: "atendimento",
    nivel: "intermediario",
    tipo_ia: "Claude",
    tags: ["tom-de-voz", "padronizacao", "equipe"],
    tempo_leitura: 2,
    exemplo_resultado: "Guia com 3 características de tom, cada uma com 2 exemplos de frase recomendada e 1 a evitar.",
  },

  // ---------------- PROGRAMAÇÃO ----------------
  {
    titulo: "Revisão de código e boas práticas",
    descricao: "Revisa um trecho de código e sugere melhorias de legibilidade e performance.",
    conteudo: "Revise o seguinte trecho de código em [LINGUAGEM]:\n\n[COLAR CÓDIGO]\n\nAponte problemas de legibilidade, possíveis bugs, riscos de performance e sugira uma versão refatorada com explicação das mudanças.",
    categoriaSlug: "programacao",
    nivel: "intermediario",
    tipo_ia: "Claude",
    tags: ["code-review", "refatoracao", "boas-praticas"],
    tempo_leitura: 3,
    exemplo_resultado: "Lista de problemas encontrados seguida do código refatorado com comentários explicativos.",
  },
  {
    titulo: "Explicação de erro de código",
    descricao: "Explica de forma didática o que significa um erro e como corrigi-lo.",
    conteudo: "Explique de forma simples o que significa o seguinte erro em [LINGUAGEM]:\n\n[COLAR MENSAGEM DE ERRO]\n\nDescreva a causa mais provável e mostre como corrigir, com um exemplo de código.",
    categoriaSlug: "programacao",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["debug", "erro", "aprendizado"],
    tempo_leitura: 2,
    exemplo_resultado: "Explicação da causa do erro seguida de um trecho de código corrigido.",
  },
  {
    titulo: "Geração de documentação de função",
    descricao: "Cria a documentação técnica de uma função ou método existente.",
    conteudo: "Gere a documentação no formato [JSDoc/Docstring/Outro] para a função abaixo, descrevendo parâmetros, retorno e um exemplo de uso:\n\n[COLAR FUNÇÃO]",
    categoriaSlug: "programacao",
    nivel: "iniciante",
    tipo_ia: "Copilot",
    tags: ["documentacao", "jsdoc", "codigo"],
    tempo_leitura: 1,
    exemplo_resultado: "Bloco de documentação com descrição, parâmetros, tipo de retorno e exemplo de chamada.",
  },
  {
    titulo: "Criação de testes unitários",
    descricao: "Gera testes unitários para uma função, cobrindo casos comuns e de borda.",
    conteudo: "Escreva testes unitários em [FRAMEWORK DE TESTES] para a função abaixo, cobrindo o caso esperado, um caso de borda e um caso de erro:\n\n[COLAR FUNÇÃO]",
    categoriaSlug: "programacao",
    nivel: "avancado",
    tipo_ia: "Copilot",
    tags: ["testes", "qualidade", "tdd"],
    tempo_leitura: 2,
    exemplo_resultado: "3 testes unitários com nomes descritivos cobrindo caso normal, borda e erro.",
  },
  {
    titulo: "Arquitetura de API REST",
    descricao: "Sugere a estrutura de endpoints para uma API REST de um domínio específico.",
    conteudo: "Projete a arquitetura de uma API REST para [DOMÍNIO, ex: sistema de pedidos]. Liste os principais endpoints, métodos HTTP, parâmetros esperados e exemplos de resposta em JSON.",
    categoriaSlug: "programacao",
    nivel: "avancado",
    tipo_ia: "Claude",
    tags: ["api", "rest", "arquitetura"],
    tempo_leitura: 3,
    exemplo_resultado: "Tabela de endpoints com método, rota, descrição e exemplo de payload de resposta.",
  },

  // ---------------- EXCEL ----------------
  {
    titulo: "Fórmula para somar com múltiplos critérios",
    descricao: "Gera a fórmula correta para somar valores com base em mais de uma condição.",
    conteudo: "Crie uma fórmula de Excel para somar a coluna [COLUNA DE VALORES] apenas quando a coluna [COLUNA A] for igual a [CRITÉRIO A] e a coluna [COLUNA B] for igual a [CRITÉRIO B]. Explique a fórmula passo a passo.",
    categoriaSlug: "excel",
    nivel: "intermediario",
    tipo_ia: "ChatGPT",
    tags: ["somases", "formula", "planilha"],
    tempo_leitura: 1,
    exemplo_resultado: "Fórmula usando SOMASES com explicação de cada argumento.",
  },
  {
    titulo: "Criação de dashboard simples",
    descricao: "Orienta a montagem de um dashboard de indicadores no Excel.",
    conteudo: "Explique como montar um dashboard simples no Excel para acompanhar [INDICADORES, ex: vendas mensais e ticket médio], usando tabelas dinâmicas e gráficos. Descreva o passo a passo.",
    categoriaSlug: "excel",
    nivel: "intermediario",
    tipo_ia: "ChatGPT",
    tags: ["dashboard", "tabela-dinamica", "graficos"],
    tempo_leitura: 3,
    exemplo_resultado: "Passo a passo numerado, da criação da tabela dinâmica até a montagem do gráfico final.",
  },
  {
    titulo: "Fórmula PROCV explicada",
    descricao: "Cria e explica uma fórmula PROCV (ou PROCX) para buscar dados entre planilhas.",
    conteudo: "Crie uma fórmula PROCV (ou PROCX) para buscar o valor da coluna [COLUNA DESEJADA] na planilha [NOME DA PLANILHA], com base no valor da célula [CÉLULA DE REFERÊNCIA]. Explique cada parte da fórmula.",
    categoriaSlug: "excel",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["procv", "procx", "busca"],
    tempo_leitura: 2,
    exemplo_resultado: "Fórmula completa com explicação de cada parâmetro em uma lista numerada.",
  },
  {
    titulo: "Automação de relatório com macro",
    descricao: "Gera um macro em VBA para automatizar a geração de um relatório repetitivo.",
    conteudo: "Crie uma macro em VBA para o Excel que [DESCREVER TAREFA REPETITIVA, ex: copiar dados de uma aba para outra e formatar como tabela]. Comente o código explicando cada etapa.",
    categoriaSlug: "excel",
    nivel: "avancado",
    tipo_ia: "ChatGPT",
    tags: ["vba", "macro", "automacao"],
    tempo_leitura: 3,
    exemplo_resultado: "Código VBA comentado linha a linha, pronto para colar no editor de macros.",
  },
  {
    titulo: "Organização de planilha de controle financeiro",
    descricao: "Sugere a estrutura de colunas ideal para uma planilha de controle financeiro pessoal.",
    conteudo: "Sugira a estrutura de colunas para uma planilha de controle financeiro pessoal no Excel, incluindo categorias de receita e despesa, e como calcular o saldo mensal automaticamente.",
    categoriaSlug: "excel",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["financas", "planilha", "organizacao"],
    tempo_leitura: 2,
    exemplo_resultado: "Lista de colunas sugeridas e a fórmula de saldo mensal usando SOMASE.",
  },

  // ---------------- ESTUDOS ----------------
  {
    titulo: "Resumo de texto acadêmico",
    descricao: "Resume um texto longo em tópicos claros e objetivos para revisão de estudo.",
    conteudo: "Resuma o seguinte texto em até 8 tópicos, mantendo os conceitos mais importantes para fins de estudo:\n\n[COLAR TEXTO]",
    categoriaSlug: "estudos",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["resumo", "estudo", "revisao"],
    tempo_leitura: 1,
    exemplo_resultado: "Lista com até 8 tópicos curtos, cada um representando uma ideia central do texto.",
  },
  {
    titulo: "Plano de estudos para concurso ou prova",
    descricao: "Monta um cronograma de estudos balanceado para um período definido.",
    conteudo: "Crie um plano de estudos de [NÚMERO] semanas para a prova de [MATÉRIA/CONCURSO], considerando [HORAS POR DIA] disponíveis. Distribua os temas por semana, intercalando revisão e exercícios.",
    categoriaSlug: "estudos",
    nivel: "intermediario",
    tipo_ia: "ChatGPT",
    tags: ["cronograma", "concurso", "planejamento"],
    tempo_leitura: 3,
    exemplo_resultado: "Tabela semanal com temas, horas dedicadas e dias reservados para revisão.",
  },
  {
    titulo: "Criação de flashcards de estudo",
    descricao: "Gera perguntas e respostas no formato de flashcards para memorização ativa.",
    conteudo: "Crie 10 flashcards (pergunta e resposta) sobre o tema [TEMA DE ESTUDO], no formato adequado para memorização ativa e revisão espaçada.",
    categoriaSlug: "estudos",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["flashcards", "memorizacao", "revisao"],
    tempo_leitura: 1,
    exemplo_resultado: "Lista numerada de 10 pares de pergunta e resposta, curtos e diretos.",
  },
  {
    titulo: "Explicação de conceito complexo de forma simples",
    descricao: "Explica um conceito difícil usando analogias e linguagem acessível.",
    conteudo: "Explique o conceito de [CONCEITO COMPLEXO] como se estivesse explicando para alguém sem conhecimento prévio no assunto, usando uma analogia do dia a dia.",
    categoriaSlug: "estudos",
    nivel: "iniciante",
    tipo_ia: "Claude",
    tags: ["explicacao", "analogia", "aprendizado"],
    tempo_leitura: 1,
    exemplo_resultado: "Explicação em 2 parágrafos curtos, com uma analogia simples no meio do texto.",
  },
  {
    titulo: "Simulado de perguntas para prova",
    descricao: "Gera um conjunto de questões de múltipla escolha sobre um tema de estudo.",
    conteudo: "Crie 5 questões de múltipla escolha sobre o tema [TEMA], com 4 alternativas cada, indicando a resposta correta e uma breve justificativa para cada uma.",
    categoriaSlug: "estudos",
    nivel: "intermediario",
    tipo_ia: "ChatGPT",
    tags: ["simulado", "questoes", "avaliacao"],
    tempo_leitura: 2,
    exemplo_resultado: "5 questões numeradas com 4 alternativas e o gabarito comentado ao final.",
  },

  // ---------------- PRODUTIVIDADE ----------------
  {
    titulo: "Organização de tarefas por prioridade",
    descricao: "Organiza uma lista de tarefas usando a matriz de Eisenhower.",
    conteudo: "Organize a seguinte lista de tarefas usando a matriz de Eisenhower (urgente/importante): [LISTAR TAREFAS]. Indique em qual quadrante cada tarefa se encaixa e sugira a ordem de execução.",
    categoriaSlug: "produtividade",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["prioridade", "eisenhower", "organizacao"],
    tempo_leitura: 2,
    exemplo_resultado: "Tarefas organizadas em 4 quadrantes com a ordem de execução sugerida.",
  },
  {
    titulo: "Rotina diária produtiva",
    descricao: "Cria uma rotina diária equilibrada com foco em produtividade e bem-estar.",
    conteudo: "Monte uma rotina diária para alguém que trabalha [PERÍODO, ex: das 9h às 18h] e quer incluir [OBJETIVOS, ex: exercício, leitura e estudo]. Distribua os blocos de tempo de forma realista.",
    categoriaSlug: "produtividade",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["rotina", "habitos", "tempo"],
    tempo_leitura: 2,
    exemplo_resultado: "Linha do tempo do dia dividida em blocos, do início da manhã ao fim da noite.",
  },
  {
    titulo: "Quebra de projeto em tarefas pequenas",
    descricao: "Divide um projeto grande em etapas menores e gerenciáveis.",
    conteudo: "Quebre o projeto [DESCREVER PROJETO] em etapas pequenas e sequenciais, cada uma com uma estimativa de tempo, até chegar a uma lista de tarefas executáveis em menos de 1 hora cada.",
    categoriaSlug: "produtividade",
    nivel: "intermediario",
    tipo_ia: "ChatGPT",
    tags: ["projetos", "planejamento", "tarefas"],
    tempo_leitura: 2,
    exemplo_resultado: "Lista de etapas numeradas, cada uma com estimativa de tempo em horas ou minutos.",
  },
  {
    titulo: "Modelo de reunião eficiente",
    descricao: "Cria a pauta de uma reunião objetiva, evitando perda de tempo.",
    conteudo: "Crie a pauta de uma reunião de [DURAÇÃO] sobre [ASSUNTO], com objetivo claro, lista de tópicos com tempo estimado para cada um e os resultados esperados ao final.",
    categoriaSlug: "produtividade",
    nivel: "iniciante",
    tipo_ia: "ChatGPT",
    tags: ["reuniao", "pauta", "gestao-do-tempo"],
    tempo_leitura: 1,
    exemplo_resultado: "Pauta com objetivo, 4 tópicos com tempo estimado e o resultado esperado de cada um.",
  },
  {
    titulo: "Técnica Pomodoro personalizada",
    descricao: "Adapta a técnica Pomodoro para uma rotina e tipo de trabalho específicos.",
    conteudo: "Adapte a técnica Pomodoro para uma pessoa que realiza [TIPO DE TRABALHO], sugerindo a duração ideal dos blocos de foco e das pausas, e como lidar com interrupções frequentes.",
    categoriaSlug: "produtividade",
    nivel: "intermediario",
    tipo_ia: "ChatGPT",
    tags: ["pomodoro", "foco", "gestao-do-tempo"],
    tempo_leitura: 2,
    exemplo_resultado: "Sugestão de duração dos blocos de foco e pausa, com dicas para lidar com interrupções.",
  },
];

async function seed() {
  console.log("🌱 Iniciando seed do PromptHub AI...");

  console.log(`→ Inserindo ${categories.length} categorias...`);
  const { data: insertedCategories, error: catError } = await supabase
    .from("categories")
    .upsert(categories, { onConflict: "slug" })
    .select("id, slug");

  if (catError) {
    console.error("❌ Erro ao inserir categorias:", catError.message);
    process.exit(1);
  }

  const slugToId = new Map((insertedCategories ?? []).map((c) => [c.slug, c.id]));

  const promptsToInsert = prompts.map(({ categoriaSlug, ...prompt }) => ({
    ...prompt,
    categoria_id: slugToId.get(categoriaSlug),
  }));

  console.log(`→ Inserindo ${promptsToInsert.length} prompts...`);
  const { error: promptError } = await supabase.from("prompts").insert(promptsToInsert);

  if (promptError) {
    console.error("❌ Erro ao inserir prompts:", promptError.message);
    process.exit(1);
  }

  console.log("✅ Seed concluído com sucesso!");
}

seed();
