-- ============================================================
-- PromptHub AI — Schema do banco de dados (PostgreSQL / Supabase)
-- Execute este arquivo no SQL Editor do Supabase antes do seed.
-- ============================================================

create extension if not exists "uuid-ossp";

-- ------------------------------------------------------------
-- Tabela: users (perfil público, espelha auth.users)
-- ------------------------------------------------------------
create table if not exists public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  nome text not null,
  email text not null,
  foto text,
  plano text not null default 'gratuito' check (plano in ('gratuito', 'pro')),
  created_at timestamptz not null default now()
);

-- Cria automaticamente um registro em public.users quando um usuário se cadastra
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.users (id, nome, email, foto)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'nome', split_part(new.email, '@', 1)),
    new.email,
    new.raw_user_meta_data->>'avatar_url'
  )
  on conflict (id) do nothing;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ------------------------------------------------------------
-- Tabela: categories
-- ------------------------------------------------------------
create table if not exists public.categories (
  id uuid primary key default uuid_generate_v4(),
  nome text not null,
  slug text not null unique,
  icone text not null default 'zap',
  descricao text,
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- Tabela: prompts
-- ------------------------------------------------------------
create table if not exists public.prompts (
  id uuid primary key default uuid_generate_v4(),
  titulo text not null,
  descricao text not null,
  conteudo text not null,
  categoria_id uuid not null references public.categories(id) on delete cascade,
  nivel text not null default 'iniciante' check (nivel in ('iniciante', 'intermediario', 'avancado')),
  tipo_ia text not null default 'ChatGPT',
  tags text[] not null default '{}',
  tempo_leitura int not null default 1,
  exemplo_resultado text,
  copy_count int not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists idx_prompts_categoria on public.prompts(categoria_id);
create index if not exists idx_prompts_nivel on public.prompts(nivel);
create index if not exists idx_prompts_tipo_ia on public.prompts(tipo_ia);
create index if not exists idx_prompts_created_at on public.prompts(created_at desc);

-- Correção (auditoria 06/2026): a aplicação busca com `ilike '%termo%'`
-- (wildcard à esquerda), que NÃO consegue usar um índice B-tree/GIN comum
-- baseado em to_tsvector. Trocamos por índices de trigrama (pg_trgm), que
-- são o índice correto para acelerar ILIKE com wildcard nas duas pontas.
create extension if not exists pg_trgm;

create index if not exists idx_prompts_titulo_trgm
  on public.prompts using gin (titulo gin_trgm_ops);

create index if not exists idx_prompts_descricao_trgm
  on public.prompts using gin (descricao gin_trgm_ops);

-- Índice GIN para o filtro por tag (array), antes sem índice dedicado.
create index if not exists idx_prompts_tags_gin
  on public.prompts using gin (tags);

-- ------------------------------------------------------------
-- Tabela: history (prompts copiados por usuário)
-- ------------------------------------------------------------
create table if not exists public.history (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.users(id) on delete cascade,
  prompt_id uuid not null references public.prompts(id) on delete cascade,
  created_at timestamptz not null default now()
);

create index if not exists idx_history_user on public.history(user_id);
create index if not exists idx_history_prompt on public.history(prompt_id);

-- ------------------------------------------------------------
-- RPC: incrementa o contador de cópias de um prompt
-- ------------------------------------------------------------
-- Correção de segurança (auditoria 06/2026): a versão anterior não exigia
-- autenticação nem tinha qualquer limite, permitindo que qualquer visitante
-- anônimo inflasse copy_count indefinidamente via chamadas repetidas.
-- Agora a função: (1) exige um usuário autenticado, (2) ignora chamadas
-- repetidas do mesmo usuário para o mesmo prompt em uma janela curta de
-- tempo, evitando spam/clique repetido.
create or replace function public.increment_copy_count(prompt_id uuid)
returns void as $$
declare
  current_user_id uuid := auth.uid();
begin
  if current_user_id is null then
    raise exception 'Authentication required to register a prompt copy';
  end if;

  if exists (
    select 1
    from public.history h
    where h.user_id = current_user_id
      and h.prompt_id = increment_copy_count.prompt_id
      and h.created_at > now() - interval '10 seconds'
  ) then
    return;
  end if;

  update public.prompts set copy_count = copy_count + 1 where id = prompt_id;
end;
$$ language plpgsql security definer set search_path = public;

-- Remove a execução pública (anon) e restringe a usuários autenticados.
revoke all on function public.increment_copy_count(uuid) from public;
revoke all on function public.increment_copy_count(uuid) from anon;
grant execute on function public.increment_copy_count(uuid) to authenticated;

-- ------------------------------------------------------------
-- Row Level Security
-- ------------------------------------------------------------
alter table public.users enable row level security;
alter table public.categories enable row level security;
alter table public.prompts enable row level security;
alter table public.history enable row level security;

-- categories e prompts: leitura pública (qualquer visitante pode ver)
create policy "Categorias são públicas para leitura"
  on public.categories for select using (true);

create policy "Prompts são públicos para leitura"
  on public.prompts for select using (true);

-- users: cada usuário só vê/edita o próprio perfil
create policy "Usuário vê o próprio perfil"
  on public.users for select using (auth.uid() = id);

create policy "Usuário edita o próprio perfil"
  on public.users for update using (auth.uid() = id);

-- history: cada usuário só vê/insere o próprio histórico
create policy "Usuário vê o próprio histórico"
  on public.history for select using (auth.uid() = user_id);

create policy "Usuário insere no próprio histórico"
  on public.history for insert with check (auth.uid() = user_id);
